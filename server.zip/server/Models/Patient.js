const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  username: {
    type: String,
   
  },
  name: {
    type: String,
  
  },
  email: {
    type: String,
    
  },
  password: {
    type: String,

  },
  dateOfBirth: {
    type: Date,

  },
  gender: {
    type: String,

  },
  mobileNumber: {
    type: String,

  },
  emergencyContact: {
    fullName: {
      type: String,

    },
    mobileNumber: {
      type: String,

    },
    relation: {
      type: String,

    },
  },
}, { timestamps: true });

const Patient = mongoose.model('Patient', patientSchema);

module.exports = Patient;
